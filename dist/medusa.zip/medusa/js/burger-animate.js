$(document).ready(function() {
$('button#burger-menu').click(function() {
  $(this).toggleClass('active');
});
});
